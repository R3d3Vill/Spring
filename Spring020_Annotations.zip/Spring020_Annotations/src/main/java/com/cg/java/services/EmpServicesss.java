package com.cg.java.services;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component("empService")
public class EmpServicesss implements InitializingBean, DisposableBean{
	@Value("Capgemini Pune")
	private String companyName;
	@Value("Talwade")
	private String address;
	@Value("50000")
	private int sall;
	
	

	public EmpServicesss(String companyName, String address, int sall) {
		super();
		this.companyName = companyName;
		this.address = address;
		this.sall = sall;
		System.out.println("three para const.");
	}

	public EmpServicesss(String companyName, String address) {
	System.out.println("in two para const.");
		this.companyName = companyName;
		this.address = address;
	}
	
//	@Autowired
	private SalaryServices salService;
	
	
	
	public SalaryServices getSalService() {
		return salService;
	}
	@Autowired
	@Qualifier("empServices")
	public void setSalService(SalaryServices salService) {
		this.salService = salService;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public EmpServicesss()
	{
		System.out.println("Object ban gya");
	}
	
public String getMessage()
{
	return "Welcome Spring Training!\n"+ companyName +"\n"+ address +"\nSalary ="+sall +"\n"+salService.calcSalary();
}

public void afterPropertiesSet() throws Exception {
	// TODO Auto-generated method stub
	
}

public void destroy() throws Exception {
	// TODO Auto-generated method stub
	
}

}
