package com.cg.java.tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.services.EmpServicesss;
import com.cg.java.services.SalaryServices;

public class Test010_Context {

	public static void main(String[] args) {
		//1. create spring context, Spring Container.
		ApplicationContext ctx= new ClassPathXmlApplicationContext("springCore.xml");
		EmpServicesss services=(EmpServicesss) ctx.getBean("empService");
		System.out.println(services.getMessage());
	

	}

}
