package com.cg.java.services;

import org.springframework.stereotype.Component;

@Component("empServices")
public class SalaryServices {
	 SalaryServices(){
		System.out.println("Onject ban gya - Salary Service");
	}
	
	public String calcSalary()
	{
		return "Calcuklated slasary";
	}

}
